# YOLO-SLD Dashboard

A professional full-stack web application for the **YOLO-SLD License Plate Detection** research system.  
Built with **Node.js + Express + MongoDB + EJS**.

---

## 📁 Project Structure

```
yolo-sld-app/
├── config/
│   └── db.js              # MongoDB connection
├── middleware/
│   └── auth.js            # Session auth guards
├── models/
│   ├── User.js            # Mongoose User schema
│   └── Detection.js       # Mongoose Detection schema
├── public/
│   ├── css/style.css      # All styles
│   └── js/main.js         # Chart.js + live refresh
├── routes/
│   ├── auth.js            # Register / Login / Logout
│   └── dashboard.js       # Dashboard + API routes
├── views/
│   ├── register.ejs       # Registration page
│   ├── login.ejs          # Login page
│   ├── dashboard.ejs      # Main dashboard
│   └── 404.ejs            # 404 page
├── .env                   # Environment variables
├── .env.example           # Example env file
├── server.js              # Entry point
└── package.json
```

---

## 🚀 Quick Start

### Prerequisites
- **Node.js** v18+ — https://nodejs.org
- **MongoDB** (optional) — https://www.mongodb.com/try/download/community
  - The app runs **without MongoDB** using an in-memory store.

### 1. Install dependencies
```bash
npm install
```

### 2. Configure environment
Edit `.env` if needed (defaults work out of the box):
```env
PORT=3000
MONGODB_URI=mongodb://localhost:27017/yolo_sld_db
SESSION_SECRET=yolo_sld_super_secret_key_2024
NODE_ENV=development
```

### 3. Run the app
```bash
# Production
npm start

# Development (auto-restart on file changes)
npm run dev
```

### 4. Open in browser
```
http://localhost:3000
```

---

## 🔑 Usage Flow

1. **Register** → `/register` — Create your account
2. **Login** → `/login` — Sign in with your credentials
3. **Dashboard** → `/dashboard` — Explore the detection analytics
4. **Logout** → Sidebar button or `/logout`

---

## 📊 Dashboard Features

| Feature | Description |
|---------|-------------|
| Metric Cards | mAP@0.5 (98.91%), FPS, Parameters, Db Accuracy |
| Subset Bar Chart | YOLO-SLD vs YOLOv7 across all 7 CCPD subsets |
| Attention Doughnut | SimAM, CBAM, SE, CA, SA comparison |
| Live Detections | Real-time table with confidence bars |
| Benchmark Table | Leaderboard vs SSD, Faster-RCNN, VertexNet, etc. |
| Training Loss | SimAM vs CBAM convergence over 20 epochs |
| Radar Chart | 6-dimension capability comparison |
| Ablation Table | Backbone + Head attention mechanism breakdown |

---

## 🗄️ MongoDB Note

The app **gracefully falls back** to an in-memory store if MongoDB is not running.  
To enable full persistence, start MongoDB and ensure `MONGODB_URI` in `.env` is correct.

---

## 📦 Tech Stack

- **Backend**: Node.js, Express 4, EJS templates
- **Database**: MongoDB + Mongoose (optional)
- **Auth**: express-session + bcryptjs
- **Charts**: Chart.js 4
- **Fonts**: DM Sans + Space Mono (Google Fonts)

---

## 📄 Reference

> Chung, M.-A., Lin, Y.-J., & Lin, C.-W. (2024). YOLO-SLD: An Attention Mechanism-Improved YOLO for License Plate Detection. *IEEE Access*, 12, 89035–89045. DOI: [10.1109/ACCESS.2024.3419587](https://doi.org/10.1109/ACCESS.2024.3419587)
