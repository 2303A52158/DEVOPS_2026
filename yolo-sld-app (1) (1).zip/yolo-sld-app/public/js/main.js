/* YOLO-SLD Dashboard - All interactions fixed */

document.addEventListener('DOMContentLoaded', function () {
  initNav();
  initCharts();
  initSubsets();
  initRefresh();
  animateMetrics();
  initTooltips();
});

/* ─── NAV SWITCHING ─── */
function initNav() {
  document.querySelectorAll('.nav-item[data-nav]').forEach(function(item) {
    item.addEventListener('click', function() {
      // Active state
      document.querySelectorAll('.nav-item').forEach(function(n) { n.classList.remove('active'); });
      item.classList.add('active');

      // Update topbar title
      var titleEl = document.getElementById('pageTitle');
      var subEl   = document.getElementById('pageSubtitle');
      if (titleEl) titleEl.textContent = item.getAttribute('data-title') || 'Dashboard';
      if (subEl)   subEl.textContent   = item.getAttribute('data-sub')   || '';

      // Hide all sections
      document.querySelectorAll('.dash-section').forEach(function(s) {
        s.style.display = 'none';
      });

      // Show target section
      var sectionMap = {
        'nav-dashboard':   'section-dashboard',
        'nav-detections':  'section-detections',
        'nav-attention':   'section-attention',
        'nav-ccpd':        'section-ccpd',
        'nav-performance': 'section-performance',
        'nav-reports':     'section-reports',
        'nav-users':       'section-users',
        'nav-settings':    'section-settings'
      };
      var key = item.getAttribute('data-nav');
      var target = document.getElementById(sectionMap[key]);
      if (target) {
        target.style.display = 'block';
        // Re-init charts for sections that need it
        setTimeout(function() {
          if (key === 'nav-dashboard')   { buildSubsetChart(); buildAttentionChart(); }
          if (key === 'nav-performance') { buildLossChart(); buildRadarChart(); }
          if (key === 'nav-attention')   { buildAttentionBarChart(); }
        }, 50);
      }
    });
  });
}

/* ─── CHARTS ─── */
var charts = {};

function initCharts() {
  buildSubsetChart();
  buildAttentionChart();
  buildLossChart();
  buildRadarChart();
  buildAttentionBarChart();
}

function buildSubsetChart() {
  var ctx = document.getElementById('subsetChart');
  if (!ctx) return;
  if (charts.subset) { charts.subset.destroy(); charts.subset = null; }
  charts.subset = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ['Base', 'Weather', 'Tilt', 'Rotate', 'Fn', 'Db', 'Challenge'],
      datasets: [
        { label: 'YOLO-SLD', data: [99.70,99.70,99.50,99.60,98.20,96.70,99.00], backgroundColor: 'rgba(0,200,255,0.78)', borderRadius: 5, borderSkipped: false },
        { label: 'YOLOv7',   data: [99.80,99.80,99.40,99.60,98.00,93.50,99.00], backgroundColor: 'rgba(124,58,237,0.60)', borderRadius: 5, borderSkipped: false }
      ]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { display: false }, tooltip: { callbacks: { label: function(c) { return ' ' + c.dataset.label + ': ' + c.raw + '%'; } } } },
      scales: {
        x: { ticks: { color: '#7f93a8', font: { size: 11 }, autoSkip: false }, grid: { color: 'rgba(0,200,255,0.04)' } },
        y: { min: 88, max: 100, ticks: { color: '#7f93a8', font: { size: 11 }, callback: function(v) { return v + '%'; } }, grid: { color: 'rgba(0,200,255,0.06)' } }
      }
    }
  });
}

function buildAttentionChart() {
  var ctx = document.getElementById('attentionChart');
  if (!ctx) return;
  if (charts.attention) { charts.attention.destroy(); charts.attention = null; }
  charts.attention = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: ['SimAM 98.74%', 'CBAM 98.61%', 'SE 67.03%', 'CA 67.67%', 'SA 65.09%'],
      datasets: [{ data: [98.74,98.61,67.03,67.67,65.09], backgroundColor: ['#00c8ff','#7c3aed','#f59e0b','#10b981','#4a5f74'], borderWidth: 0, hoverOffset: 8 }]
    },
    options: {
      responsive: true, maintainAspectRatio: false, cutout: '66%',
      plugins: { legend: { display: true, position: 'bottom', labels: { color: '#7f93a8', font: { size: 11 }, padding: 10, boxWidth: 9, boxHeight: 9 } } }
    }
  });
}

function buildLossChart() {
  var ctx = document.getElementById('lossChart');
  if (!ctx) return;
  if (charts.loss) { charts.loss.destroy(); charts.loss = null; }
  var epochs   = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20];
  var simLoss  = [0.792,0.641,0.519,0.422,0.346,0.286,0.238,0.201,0.171,0.148,0.130,0.115,0.103,0.093,0.085,0.079,0.073,0.068,0.064,0.061];
  var cbamLoss = [0.831,0.683,0.567,0.472,0.396,0.335,0.287,0.248,0.216,0.190,0.170,0.153,0.139,0.127,0.117,0.108,0.101,0.095,0.090,0.086];
  charts.loss = new Chart(ctx, {
    type: 'line',
    data: {
      labels: epochs,
      datasets: [
        { label: 'YOLO-SLD (SimAM)', data: simLoss,  borderColor: '#00c8ff', backgroundColor: 'rgba(0,200,255,0.06)', borderWidth: 2.5, pointRadius: 2, fill: true, tension: 0.4 },
        { label: 'YOLOv7-CBAM',      data: cbamLoss, borderColor: '#7c3aed', backgroundColor: 'rgba(124,58,237,0.04)', borderWidth: 2,   pointRadius: 2, fill: true, tension: 0.4 }
      ]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { labels: { color: '#7f93a8', font: { size: 11 }, boxWidth: 12 } } },
      scales: {
        x: { title: { display: true, text: 'Epoch', color: '#7f93a8', font: { size: 11 } }, ticks: { color: '#7f93a8', font: { size: 11 } }, grid: { color: 'rgba(0,200,255,0.04)' } },
        y: { title: { display: true, text: 'Loss', color: '#7f93a8', font: { size: 11 } }, ticks: { color: '#7f93a8', font: { size: 11 }, callback: function(v) { return v.toFixed(2); } }, grid: { color: 'rgba(0,200,255,0.06)' } }
      }
    }
  });
}

function buildRadarChart() {
  var ctx = document.getElementById('radarChart');
  if (!ctx) return;
  if (charts.radar) { charts.radar.destroy(); charts.radar = null; }
  charts.radar = new Chart(ctx, {
    type: 'radar',
    data: {
      labels: ['Accuracy', 'Speed', 'Lightweight', 'Dark Images', 'Tilt Resist.', 'Weather'],
      datasets: [
        { label: 'YOLO-SLD', data: [98,91,96,97,99,99], borderColor: '#00c8ff', backgroundColor: 'rgba(0,200,255,0.12)', pointBackgroundColor: '#00c8ff', borderWidth: 2, pointRadius: 3 },
        { label: 'YOLOv7',   data: [95,97,90,83,97,99], borderColor: '#7c3aed', backgroundColor: 'rgba(124,58,237,0.08)', pointBackgroundColor: '#7c3aed', borderWidth: 2, pointRadius: 3 }
      ]
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { labels: { color: '#7f93a8', font: { size: 11 }, boxWidth: 10 } } },
      scales: { r: { min: 70, max: 100, ticks: { color: '#4a5f74', font: { size: 10 }, backdropColor: 'transparent', stepSize: 10 }, grid: { color: 'rgba(0,200,255,0.08)' }, angleLines: { color: 'rgba(0,200,255,0.08)' }, pointLabels: { color: '#7f93a8', font: { size: 10 } } } }
    }
  });
}

function buildAttentionBarChart() {
  var ctx = document.getElementById('attentionBarChart');
  if (!ctx) return;
  if (charts.attnBar) { charts.attnBar.destroy(); charts.attnBar = null; }
  charts.attnBar = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ['SimAM BB+Head', 'CBAM BB+Head', 'SimAM BB only', 'SimAM Head only', 'SE', 'CA', 'SA'],
      datasets: [{ label: 'mAP @ 0.5', data: [98.74,98.61,84.00,86.27,67.03,67.67,65.09], backgroundColor: ['#00c8ff','#7c3aed','rgba(0,200,255,0.5)','rgba(0,200,255,0.35)','#f59e0b','#10b981','#4a5f74'], borderRadius: 5, borderSkipped: false }]
    },
    options: {
      indexAxis: 'y', responsive: true, maintainAspectRatio: false,
      plugins: { legend: { display: false }, tooltip: { callbacks: { label: function(c) { return ' mAP: ' + c.raw + '%'; } } } },
      scales: {
        x: { min: 60, max: 100, ticks: { color: '#7f93a8', font: { size: 11 }, callback: function(v) { return v + '%'; } }, grid: { color: 'rgba(0,200,255,0.06)' } },
        y: { ticks: { color: '#7f93a8', font: { size: 11 } }, grid: { display: false } }
      }
    }
  });
}

/* ─── SUBSET CARDS ─── */
function initSubsets() {
  document.querySelectorAll('.subset-card').forEach(function(card) {
    card.addEventListener('click', function() {
      document.querySelectorAll('.subset-card').forEach(function(c) { c.classList.remove('is-active'); });
      card.classList.add('is-active');
      var idx = parseInt(card.getAttribute('data-idx') || '0');
      highlightSubset(idx);
    });
  });
}

function highlightSubset(idx) {
  if (!charts.subset) return;
  charts.subset.data.datasets[0].backgroundColor = charts.subset.data.datasets[0].data.map(function(_, i) {
    return i === idx ? '#00c8ff' : 'rgba(0,200,255,0.25)';
  });
  charts.subset.data.datasets[1].backgroundColor = charts.subset.data.datasets[1].data.map(function(_, i) {
    return i === idx ? '#a78bfa' : 'rgba(124,58,237,0.2)';
  });
  charts.subset.update();
  setTimeout(function() {
    if (!charts.subset) return;
    charts.subset.data.datasets[0].backgroundColor = 'rgba(0,200,255,0.78)';
    charts.subset.data.datasets[1].backgroundColor = 'rgba(124,58,237,0.60)';
    charts.subset.update();
  }, 2000);
}

/* ─── FILTER CHIPS (Detections page) ─── */
document.addEventListener('click', function(e) {
  if (e.target.classList.contains('filter-chip')) {
    document.querySelectorAll('.filter-chip').forEach(function(c) { c.classList.remove('active'); });
    e.target.classList.add('active');
    filterDetectionRows(e.target.getAttribute('data-filter'));
  }
});

function filterDetectionRows(subset) {
  var rows = document.querySelectorAll('#detectionTbodyFull tr');
  rows.forEach(function(row) {
    var cell = row.cells[2];
    if (!cell) return;
    row.style.display = (subset === 'all' || cell.textContent.trim() === subset) ? '' : 'none';
  });
}

/* ─── REFRESH BUTTON ─── */
var refreshCount = 0;
var newPlates  = ['JX·H10021','GS·K88341','YN·L33219','HL·M50087','XZ·P77412','QH·R12345','NX·S98765','SD·T66123','BJ·W44021'];
var allSubsets = ['Base','Db','Fn','Weather','Tilt','Rotate','Challenge'];
var allStatuses= ['matched','matched','matched','low_light','review'];

function initRefresh() {
  var btn = document.getElementById('refreshBtn');
  if (!btn) return;
  btn.addEventListener('click', function() {
    var svg = btn.querySelector('svg');
    if (svg) svg.style.transform = 'rotate(360deg)';
    btn.disabled = true;
    liveRefresh();
    setTimeout(function() {
      if (svg) { svg.style.transition = 'none'; svg.style.transform = 'rotate(0deg)'; }
      btn.disabled = false;
    }, 800);
  });
  setInterval(liveRefresh, 30000);
}

function liveRefresh() {
  fetch('/api/detections')
    .then(function(r) { return r.json(); })
    .then(function(json) {
      if (json.success) updateTable(json.data);
      else injectFakeRow();
    })
    .catch(function() { injectFakeRow(); });
}

function injectFakeRow() {
  var tbody = document.getElementById('detectionTbody');
  if (!tbody) return;
  refreshCount++;
  var conf      = (88 + Math.random() * 12).toFixed(1);
  var plate     = newPlates[refreshCount % newPlates.length];
  var subset    = allSubsets[refreshCount % allSubsets.length];
  var status    = allStatuses[refreshCount % allStatuses.length];
  var badgeCls  = status === 'matched' ? 'badge-success' : status === 'low_light' ? 'badge-warning' : 'badge-danger';
  var badgeTxt  = status === 'matched' ? '✓ Matched' : status === 'low_light' ? '~ Low-light' : '✗ Review';
  var time      = new Date().toLocaleTimeString('en-US', { hour12: false });

  var row = document.createElement('tr');
  row.innerHTML =
    '<td><span class="plate-tag">' + plate + '</span></td>' +
    '<td><div class="conf-wrap"><div class="conf-bar"><div class="conf-fill" style="width:' + conf + '%;"></div></div><span class="conf-val">' + conf + '%</span></div></td>' +
    '<td><span style="font-size:12px;color:var(--text2);">' + subset + '</span></td>' +
    '<td><span class="badge ' + badgeCls + '">' + badgeTxt + '</span></td>' +
    '<td style="font-size:12px;color:var(--text2);">' + time + '</td>';

  row.style.opacity = '0';
  row.style.background = 'rgba(0,200,255,0.05)';
  tbody.insertBefore(row, tbody.firstChild);
  setTimeout(function() { row.style.transition = 'opacity 0.4s, background 1.2s'; row.style.opacity = '1'; row.style.background = ''; }, 20);
  while (tbody.rows.length > 10) tbody.deleteRow(tbody.rows.length - 1);

  // Mirror to full detections table
  var tbody2 = document.getElementById('detectionTbodyFull');
  if (tbody2) {
    var row2 = row.cloneNode(true);
    row2.style.opacity = '1'; row2.style.background = '';
    tbody2.insertBefore(row2, tbody2.firstChild);
    while (tbody2.rows.length > 20) tbody2.deleteRow(tbody2.rows.length - 1);
  }
}

function updateTable(data) {
  var tbody = document.getElementById('detectionTbody');
  if (!tbody || !data) return;
  data.slice(0, 3).forEach(function(d) {
    var conf     = (d.confidence * 100).toFixed(1);
    var badgeCls = d.status === 'matched' ? 'badge-success' : d.status === 'low_light' ? 'badge-warning' : 'badge-danger';
    var badgeTxt = d.status === 'matched' ? '✓ Matched' : d.status === 'low_light' ? '~ Low-light' : '✗ Review';
    var row = document.createElement('tr');
    row.innerHTML =
      '<td><span class="plate-tag">' + d.plateNumber + '</span></td>' +
      '<td><div class="conf-wrap"><div class="conf-bar"><div class="conf-fill" style="width:' + conf + '%;"></div></div><span class="conf-val">' + conf + '%</span></div></td>' +
      '<td><span style="font-size:12px;color:var(--text2);">' + d.subset + '</span></td>' +
      '<td><span class="badge ' + badgeCls + '">' + badgeTxt + '</span></td>' +
      '<td style="font-size:12px;color:var(--text2);">' + (d.time || new Date().toLocaleTimeString('en-US',{hour12:false})) + '</td>';
    row.style.opacity = '0';
    tbody.insertBefore(row, tbody.firstChild);
    setTimeout(function() { row.style.transition = 'opacity 0.4s'; row.style.opacity = '1'; }, 20);
  });
  while (tbody.rows.length > 10) tbody.deleteRow(tbody.rows.length - 1);
}

/* ─── METRIC COUNTER ANIMATION ─── */
function animateMetrics() {
  document.querySelectorAll('[data-count]').forEach(function(el) {
    var target   = parseFloat(el.getAttribute('data-count'));
    var suffix   = el.getAttribute('data-suffix')   || '';
    var decimals = parseInt(el.getAttribute('data-decimals') || '0');
    var startTs  = null;
    var duration = 1400;
    function step(ts) {
      if (!startTs) startTs = ts;
      var progress = Math.min((ts - startTs) / duration, 1);
      var ease = 1 - Math.pow(1 - progress, 3);
      el.textContent = (target * ease).toFixed(decimals) + suffix;
      if (progress < 1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  });
}

/* ─── TOOLTIPS ─── */
function initTooltips() {
  var tips = {
    'tip-map':    'mAP (mean Average Precision) at IoU 0.5 on CCPD 2019 — best among all compared models',
    'tip-fps':    'Frames per second measured on NVIDIA GeForce RTX 3060 GPU',
    'tip-params': '70.1M parameters — 1.2M fewer than the YOLOv7 baseline (71.3M)',
    'tip-db':     'Accuracy on CCPD-Db (dark/uneven illumination) — improved from 93.5% to 96.7%'
  };
  Object.keys(tips).forEach(function(id) {
    var el = document.getElementById(id);
    if (!el) return;
    var tip = null;
    el.addEventListener('mouseenter', function(e) {
      tip = document.createElement('div');
      tip.className = 'tooltip-popup';
      tip.textContent = tips[id];
      document.body.appendChild(tip);
      tip.style.left = (e.clientX + 14) + 'px';
      tip.style.top  = (e.clientY - 10) + 'px';
    });
    el.addEventListener('mousemove', function(e) {
      if (tip) { tip.style.left = (e.clientX + 14) + 'px'; tip.style.top = (e.clientY - 10) + 'px'; }
    });
    el.addEventListener('mouseleave', function() {
      if (tip) { tip.remove(); tip = null; }
    });
  });
}

/* ─── TOAST NOTIFICATIONS ─── */
function showToast(msg, type) {
  type = type || 'info';
  var container = document.getElementById('toastContainer');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toastContainer';
    container.style.cssText = 'position:fixed;bottom:24px;right:24px;z-index:9999;display:flex;flex-direction:column;gap:8px;pointer-events:none;';
    document.body.appendChild(container);
  }
  var colors = {
    success: { bg: 'rgba(16,185,129,0.15)',  border: 'rgba(16,185,129,0.35)',  color: '#6ee7b7' },
    error:   { bg: 'rgba(239,68,68,0.15)',   border: 'rgba(239,68,68,0.35)',   color: '#fca5a5' },
    info:    { bg: 'rgba(0,200,255,0.12)',   border: 'rgba(0,200,255,0.30)',   color: '#67e8f9' }
  };
  var c = colors[type] || colors.info;
  var toast = document.createElement('div');
  toast.style.cssText = 'background:' + c.bg + ';border:1px solid ' + c.border + ';color:' + c.color + ';padding:11px 18px;border-radius:10px;font-size:13px;font-family:var(--sans);opacity:0;transform:translateY(10px);transition:all 0.25s;min-width:200px;pointer-events:none;';
  toast.textContent = msg;
  container.appendChild(toast);
  requestAnimationFrame(function() { toast.style.opacity = '1'; toast.style.transform = 'translateY(0)'; });
  setTimeout(function() {
    toast.style.opacity = '0'; toast.style.transform = 'translateY(10px)';
    setTimeout(function() { toast.remove(); }, 300);
  }, 3000);
}
window.showToast = showToast;

/* ─── SETTINGS TOGGLES ─── */
document.addEventListener('change', function(e) {
  if (e.target.classList.contains('setting-toggle')) {
    var label = e.target.getAttribute('data-label') || 'Setting';
    showToast(label + (e.target.checked ? ' enabled' : ' disabled'), e.target.checked ? 'success' : 'info');
  }
});

/* ─── LOGOUT CONFIRM ─── */
var logoutLink = document.getElementById('logoutLink');
if (logoutLink) {
  logoutLink.addEventListener('click', function(e) {
    e.preventDefault();
    if (confirm('Sign out of YOLO-SLD Dashboard?')) {
      window.location.href = '/logout';
    }
  });
}
