const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const { requireGuest, requireAuth } = require('../middleware/auth');

// In-memory store as fallback when MongoDB is unavailable
const memoryStore = { users: [] };

let User;
try {
  User = require('../models/User');
} catch (e) {}

// ─── GET /register ───
router.get('/register', requireGuest, (req, res) => {
  res.render('register', { error: null, success: null, formData: {} });
});

// ─── POST /register ───
router.post('/register', requireGuest, async (req, res) => {
  const { name, email, username, password, confirmPassword, role } = req.body;
  const formData = { name, email, username, role };

  if (!name || !email || !username || !password || !confirmPassword) {
    return res.render('register', { error: 'All fields are required.', success: null, formData });
  }
  if (password !== confirmPassword) {
    return res.render('register', { error: 'Passwords do not match.', success: null, formData });
  }
  if (password.length < 6) {
    return res.render('register', { error: 'Password must be at least 6 characters.', success: null, formData });
  }

  try {
    if (User && require('mongoose').connection.readyState === 1) {
      const existing = await User.findOne({ $or: [{ email }, { username }] });
      if (existing) {
        const field = existing.email === email.toLowerCase() ? 'Email' : 'Username';
        return res.render('register', { error: `${field} already exists.`, success: null, formData });
      }
      await User.create({ name, email, username, password, role: role || 'researcher' });
    } else {
      // Memory fallback
      const exists = memoryStore.users.find(u => u.email === email || u.username === username);
      if (exists) {
        return res.render('register', { error: 'Email or username already exists.', success: null, formData });
      }
      const hashed = await bcrypt.hash(password, 12);
      memoryStore.users.push({
        _id: Date.now().toString(),
        name, email: email.toLowerCase(), username,
        password: hashed, role: role || 'researcher',
        createdAt: new Date()
      });
    }
    res.render('register', {
      error: null,
      success: 'Account created successfully! You can now sign in.',
      formData: {}
    });
  } catch (err) {
    res.render('register', { error: 'Registration failed. Please try again.', success: null, formData });
  }
});

// ─── GET /login ───
router.get('/login', requireGuest, (req, res) => {
  res.render('login', { error: null, formData: {} });
});

// ─── POST /login ───
router.post('/login', requireGuest, async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.render('login', { error: 'Username and password are required.', formData: { username } });
  }

  try {
    let user = null;

    if (User && require('mongoose').connection.readyState === 1) {
      user = await User.findOne({
        $or: [{ username }, { email: username.toLowerCase() }]
      });
      if (!user || !(await user.comparePassword(password))) {
        return res.render('login', { error: 'Invalid credentials. Please try again.', formData: { username } });
      }
      await User.findByIdAndUpdate(user._id, { lastLogin: new Date() });
    } else {
      // Memory fallback
      user = memoryStore.users.find(u => u.username === username || u.email === username.toLowerCase());
      if (!user) {
        return res.render('login', { error: 'Invalid credentials. Please try again.', formData: { username } });
      }
      const match = await bcrypt.compare(password, user.password);
      if (!match) {
        return res.render('login', { error: 'Invalid credentials. Please try again.', formData: { username } });
      }
    }

    req.session.userId = user._id.toString();
    req.session.userName = user.name;
    req.session.userRole = user.role;
    req.session.userInitials = user.name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);

    res.redirect('/dashboard');
  } catch (err) {
    res.render('login', { error: 'Login failed. Please try again.', formData: { username } });
  }
});

// ─── GET /logout ───
router.get('/logout', requireAuth, (req, res) => {
  req.session.destroy(() => {
    res.redirect('/login');
  });
});

module.exports = router;
