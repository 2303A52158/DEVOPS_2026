const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth');

// ─── Stats data (simulated / seeded) ───
const subsetStats = [
  { name: 'Base',      yoloSLD: 99.70, yoloV7: 99.80, count: '200K', icon: '📦' },
  { name: 'Weather',   yoloSLD: 99.70, yoloV7: 99.80, count: '10K',  icon: '🌧️' },
  { name: 'Tilt',      yoloSLD: 99.50, yoloV7: 99.40, count: '30K',  icon: '↗️' },
  { name: 'Rotate',    yoloSLD: 99.60, yoloV7: 99.60, count: '10K',  icon: '🔄' },
  { name: 'Fn',        yoloSLD: 98.20, yoloV7: 98.00, count: '20K',  icon: '🔭' },
  { name: 'Db',        yoloSLD: 96.70, yoloV7: 93.50, count: '20K',  icon: '🌑' },
  { name: 'Challenge', yoloSLD: 99.00, yoloV7: 99.00, count: '10K',  icon: '⚡' },
];

const modelBenchmarks = [
  { name: 'YOLO-SLD (Ours)', map: 98.91, params: '70.1M', fps: 110.1, highlight: true },
  { name: 'VertexNet',       map: 98.74, params: '—',     fps: '—',   highlight: false },
  { name: 'CenterNet',       map: 98.56, params: '—',     fps: '—',   highlight: false },
  { name: 'YOLOv7',         map: 98.44, params: '71.3M', fps: 117.9, highlight: false },
  { name: 'WPOD',            map: 95.87, params: '—',     fps: '—',   highlight: false },
  { name: 'MTCNN',           map: 95.06, params: '—',     fps: '—',   highlight: false },
  { name: 'TE2E',            map: 91.47, params: '—',     fps: '—',   highlight: false },
  { name: 'SSD300',          map: 90.73, params: '—',     fps: '—',   highlight: false },
  { name: 'Faster-RCNN',     map: 88.69, params: '—',     fps: '—',   highlight: false },
];

const attentionMechanisms = [
  { name: 'SimAM',  backbone: '✓', head: '✓', map: 98.74, params: '66.4M', badge: 'Best' },
  { name: 'CBAM',   backbone: '✓', head: '✓', map: 98.61, params: '71.3M', badge: '' },
  { name: 'SE',     backbone: '✓', head: '—', map: 67.03, params: '64.0M', badge: '' },
  { name: 'CA',     backbone: '✓', head: '—', map: 67.67, params: '64.2M', badge: '' },
  { name: 'SA',     backbone: '✓', head: '—', map: 65.09, params: '63.7M', badge: '' },
];

function generateDetections(count = 10) {
  const plates = ['ANH·31528','SH·A89357','GD·B77211','BJ·D44103','ZJ·E19832','HN·F60541','FJ·G22194','XZ·H10021','YN·K88341','GS·L33219','JX·M50087','HB·P77412'];
  const subsets = ['Base','Db','Fn','Rotate','Tilt','Weather','Challenge'];
  const statuses = ['matched','matched','matched','low_light','review'];
  const result = [];
  for (let i = 0; i < count; i++) {
    const conf = 0.78 + Math.random() * 0.22;
    result.push({
      plateNumber: plates[i % plates.length],
      confidence: conf,
      confPct: (conf * 100).toFixed(1),
      subset: subsets[i % subsets.length],
      status: statuses[i % statuses.length],
      time: new Date(Date.now() - i * 3400).toLocaleTimeString('en-US', { hour12: false })
    });
  }
  return result;
}

// ─── GET /dashboard ───
router.get('/dashboard', requireAuth, (req, res) => {
  const detections = generateDetections(10);
  res.render('dashboard', {
    user: {
      name: req.session.userName,
      role: req.session.userRole,
      initials: req.session.userInitials
    },
    metrics: {
      mAP: '98.91%',
      fps: '110.1',
      params: '70.1M',
      dbAccuracy: '96.7%',
      improvement: '+0.47%',
      paramsSaved: '1.2M'
    },
    subsetStats,
    modelBenchmarks,
    attentionMechanisms,
    detections,
    page: 'dashboard'
  });
});

// ─── API: GET /api/detections (JSON endpoint) ───
router.get('/api/detections', requireAuth, (req, res) => {
  res.json({ success: true, data: generateDetections(5) });
});

module.exports = router;
