require('dotenv').config();
const express    = require('express');
const session    = require('express-session');
const morgan     = require('morgan');
const path       = require('path');
const connectDB  = require('./config/db');

const app  = express();
const PORT = process.env.PORT || 3000;

// ─── Connect to MongoDB (graceful fallback) ───
connectDB();

// ─── View engine ───
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// ─── Middleware ───
app.use(morgan('dev'));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.use(session({
  secret: process.env.SESSION_SECRET || 'fallback_secret',
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    maxAge: 1000 * 60 * 60 * 8   // 8 hours
  }
}));

// ─── Routes ───
app.use('/', require('./routes/auth'));
app.use('/', require('./routes/dashboard'));

// ─── Root redirect ───
app.get('/', (req, res) => {
  if (req.session && req.session.userId) {
    return res.redirect('/dashboard');
  }
  res.redirect('/login');
});

// ─── 404 handler ───
app.use((req, res) => {
  res.status(404).render('404', { user: req.session?.userName || null });
});

// ─── Error handler ───
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).send('Something went wrong. Please try again.');
});

app.listen(PORT, () => {
  console.log('');
  console.log('  ╔══════════════════════════════════════╗');
  console.log('  ║   YOLO-SLD Dashboard Server          ║');
  console.log(`  ║   Running at http://localhost:${PORT}   ║`);
  console.log('  ╚══════════════════════════════════════╝');
  console.log('');
});

module.exports = app;
