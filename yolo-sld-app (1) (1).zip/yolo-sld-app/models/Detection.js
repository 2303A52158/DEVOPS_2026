const mongoose = require('mongoose');

const detectionSchema = new mongoose.Schema({
  plateNumber: {
    type: String,
    required: true,
    uppercase: true,
    trim: true
  },
  confidence: {
    type: Number,
    required: true,
    min: 0,
    max: 1
  },
  subset: {
    type: String,
    enum: ['Base', 'Db', 'Fn', 'Rotate', 'Tilt', 'Weather', 'Challenge'],
    required: true
  },
  status: {
    type: String,
    enum: ['matched', 'low_light', 'review'],
    default: 'matched'
  },
  boundingBox: {
    x: Number,
    y: Number,
    width: Number,
    height: Number
  },
  model: {
    type: String,
    default: 'YOLO-SLD'
  },
  processedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('Detection', detectionSchema);
